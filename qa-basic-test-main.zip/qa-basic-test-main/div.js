function div(a, b) {
  return a / b;
}
module.exports = div;
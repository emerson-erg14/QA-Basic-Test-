const div = require('./div');

//Write all edge cases tests for div.js function.
//Example of usage div(4,2) should be 2

test("Check if it works", () => {
    expect(div(4,2)).toBe(2);
})